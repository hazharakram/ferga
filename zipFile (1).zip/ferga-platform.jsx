import { useState, useEffect, useRef } from "react";

const ORANGE = "#FF6B00";
const DARK = "#0D1B2A";
const BG = "#F8FAFC";

const translations = {
  ku: {
    dir: "rtl",
    name: "فێرگا",
    tagline: "فێربوون. گەیشتن. بەرزبوونەوە.",
    subtitle: "هەزاران مامۆستا و کۆرس بدۆزەرەوە",
    searchPlaceholder: "گەڕان بۆ مامۆستا، کۆرس، قوتابخانە...",
    searchBtn: "گەڕان",
    categories: "پۆلەکان",
    popularTeachers: "مامۆستا باشەکان",
    featuredCourses: "کۆرسە تایبەتەکان",
    featuredSchools: "قوتابخانەکان",
    bookSession: "پۆل پشکنین",
    message: "نامە",
    viewProfile: "پڕۆفایل",
    enrollNow: "تۆمارکردن",
    login: "چوونەژوورەوە",
    register: "تۆمارکردن",
    home: "سەرەکی",
    teachers: "مامۆستاکان",
    courses: "کۆرسەکان",
    schools: "قوتابخانەکان",
    dashboard: "داشبۆرد",
    students: "خوێندکاران",
    earnings: "داهات",
    bookings: "پشکنینەکان",
    settings: "ڕێکخستن",
    notifications: "ئاگادارکردنەوەکان",
    reviews: "هەڵسەنگاندنەکان",
    saved: "پاراستراوەکان",
    perHour: "/ کاتژمێر",
    rating: "هەڵسەنگاندن",
    experience: "ئەزموون",
    years: "ساڵ",
    subjects: "بابەتەکان",
    language: "زمان",
    price: "نرخ",
    online: "ئۆنلاین",
    offline: "ئۆفلاین",
    filter: "فلتەر",
    allTeachers: "هەموو مامۆستاکان",
    totalStudents: "کۆی خوێندکاران",
    totalEarnings: "کۆی داهات",
    totalSessions: "کۆی ئۆتۆمبێل",
    approveTeacher: "مامۆستا پەسەندکردن",
    manageUsers: "بەڕێوەبردنی بەکارهێنەران",
    revenue: "داهات",
    stats1: "مامۆستا",
    stats2: "خوێندکار",
    stats3: "کۆرس",
    stats4: "قوتابخانە",
    cta: "ئەمڕۆ دەست پێ بکە",
    ctaBtn: "بەخۆڕایی تۆمارکردن",
    footer: "© ٢٠٢٥ فێرگا. هەموو مافەکان پارێزراون.",
  },
  ar: {
    dir: "rtl",
    name: "فيرغا",
    tagline: "تعلم. انجز. ارتقِ.",
    subtitle: "اكتشف آلاف المعلمين والدورات",
    searchPlaceholder: "ابحث عن معلم، دورة، مدرسة...",
    searchBtn: "بحث",
    categories: "الفئات",
    popularTeachers: "المعلمون المميزون",
    featuredCourses: "الدورات المميزة",
    featuredSchools: "المدارس المميزة",
    bookSession: "احجز جلسة",
    message: "رسالة",
    viewProfile: "الملف الشخصي",
    enrollNow: "سجل الآن",
    login: "تسجيل الدخول",
    register: "إنشاء حساب",
    home: "الرئيسية",
    teachers: "المعلمون",
    courses: "الدورات",
    schools: "المدارس",
    dashboard: "لوحة التحكم",
    students: "الطلاب",
    earnings: "الأرباح",
    bookings: "الحجوزات",
    settings: "الإعدادات",
    notifications: "الإشعارات",
    reviews: "التقييمات",
    saved: "المحفوظات",
    perHour: "/ ساعة",
    rating: "التقييم",
    experience: "الخبرة",
    years: "سنة",
    subjects: "المواد",
    language: "اللغة",
    price: "السعر",
    online: "أونلاين",
    offline: "حضوري",
    filter: "تصفية",
    allTeachers: "جميع المعلمين",
    totalStudents: "إجمالي الطلاب",
    totalEarnings: "إجمالي الأرباح",
    totalSessions: "إجمالي الجلسات",
    approveTeacher: "اعتماد المعلمين",
    manageUsers: "إدارة المستخدمين",
    revenue: "الإيرادات",
    stats1: "معلم",
    stats2: "طالب",
    stats3: "دورة",
    stats4: "مدرسة",
    cta: "ابدأ اليوم",
    ctaBtn: "سجل مجاناً",
    footer: "© ٢٠٢٥ فيرغا. جميع الحقوق محفوظة.",
  },
  en: {
    dir: "ltr",
    name: "FERGA",
    tagline: "Learn. Achieve. Rise.",
    subtitle: "Discover thousands of teachers and courses",
    searchPlaceholder: "Search teachers, courses, schools...",
    searchBtn: "Search",
    categories: "Categories",
    popularTeachers: "Popular Teachers",
    featuredCourses: "Featured Courses",
    featuredSchools: "Featured Schools",
    bookSession: "Book Session",
    message: "Message",
    viewProfile: "View Profile",
    enrollNow: "Enroll Now",
    login: "Login",
    register: "Register",
    home: "Home",
    teachers: "Teachers",
    courses: "Courses",
    schools: "Schools",
    dashboard: "Dashboard",
    students: "Students",
    earnings: "Earnings",
    bookings: "Bookings",
    settings: "Settings",
    notifications: "Notifications",
    reviews: "Reviews",
    saved: "Saved",
    perHour: "/ hr",
    rating: "Rating",
    experience: "Experience",
    years: "yrs",
    subjects: "Subjects",
    language: "Language",
    price: "Price",
    online: "Online",
    offline: "In-Person",
    filter: "Filter",
    allTeachers: "All Teachers",
    totalStudents: "Total Students",
    totalEarnings: "Total Earnings",
    totalSessions: "Total Sessions",
    approveTeacher: "Approve Teachers",
    manageUsers: "Manage Users",
    revenue: "Revenue",
    stats1: "Teachers",
    stats2: "Students",
    stats3: "Courses",
    stats4: "Schools",
    cta: "Start Today",
    ctaBtn: "Register Free",
    footer: "© 2025 FERGA. All rights reserved.",
  },
};

const teachers = [
  { id: 1, name: "Zana Ahmed", nameAr: "زانا أحمد", nameKu: "زانا ئەحمەد", subject: "English · IELTS", rating: 4.8, reviews: 320, price: 15000, exp: 4, img: "ZA", color: "#FF6B00", online: true },
  { id: 2, name: "Hana Karim", nameAr: "هنا كريم", nameKu: "هانا کەریم", subject: "Math · Physics", rating: 4.9, reviews: 185, price: 12000, exp: 6, img: "HK", color: "#0D1B2A", online: true },
  { id: 3, name: "Ali Hassan", nameAr: "علي حسن", nameKu: "عەلی حەسەن", subject: "Python · CS", rating: 4.7, reviews: 74, price: 11000, exp: 3, img: "AH", color: "#16A34A", online: false },
  { id: 4, name: "Sara J.", nameAr: "سارة ج.", nameKu: "سارا ج.", subject: "Arabic · Kurdish", rating: 4.6, reviews: 52, price: 8000, exp: 2, img: "SJ", color: "#7C3AED", online: true },
];

const courses = [
  { id: 1, title: "IELTS Preparation", titleAr: "تحضير آيلتس", titleKu: "ئامادەکاری ئایلتس", price: 15000, rating: 4.7, reviews: 90, lessons: 20, level: "All Levels", color: "#FF6B00" },
  { id: 2, title: "Python Programming", titleAr: "برمجة بايثون", titleKu: "بەرنامەسازی پایتۆن", price: 20000, rating: 4.8, reviews: 133, lessons: 32, level: "Beginner", color: "#0D1B2A" },
  { id: 3, title: "Graphic Design", titleAr: "التصميم الجرافيكي", titleKu: "دیزاینی گرافیک", price: 14000, rating: 4.8, reviews: 80, lessons: 18, level: "Intermediate", color: "#7C3AED" },
  { id: 4, title: "English Speaking", titleAr: "المحادثة الإنجليزية", titleKu: "قسەکردنی ئینگلیزی", price: 12000, rating: 4.6, reviews: 61, lessons: 16, level: "All Levels", color: "#16A34A" },
];

const schools = [
  { id: 1, name: "Future International School", nameAr: "مدرسة المستقبل الدولية", nameKu: "قوتابخانەی نێودەوڵەتی داهاتوو", location: "Erbil, Kurdistan", dist: "2.3 km", rating: 4.3, reviews: 130 },
  { id: 2, name: "Knowledge Language Center", nameAr: "مركز المعرفة اللغوي", nameKu: "ناوەندی زمانی زانست", location: "Duhok, Kurdistan", dist: "3.1 km", rating: 4.8, reviews: 195 },
  { id: 3, name: "Bright Way Institute", nameAr: "معهد الطريق المشرق", nameKu: "ئینستیتوتی ڕێگای ڕووناک", location: "Sulaymaniyah, Kurdistan", dist: "4.7 km", rating: 4.5, reviews: 88 },
];

const categories = [
  { icon: "🌐", label: "Languages", labelAr: "اللغات", labelKu: "زمانەکان" },
  { icon: "📐", label: "School Subjects", labelAr: "المواد", labelKu: "بابەتەکان" },
  { icon: "💻", label: "Programming", labelAr: "البرمجة", labelKu: "بەرنامەسازی" },
  { icon: "🎨", label: "Design", labelAr: "التصميم", labelKu: "دیزاین" },
  { icon: "📊", label: "Business", labelAr: "الأعمال", labelKu: "بازرگانی" },
  { icon: "🎵", label: "Music", labelAr: "الموسيقى", labelKu: "موسیقا" },
  { icon: "💪", label: "Sports", labelAr: "الرياضة", labelKu: "وەرزش" },
  { icon: "🧘", label: "Personal Dev", labelAr: "التطوير الشخصي", labelKu: "پەرەپێدانی کەسی" },
];

const avatarColors = ["#FF6B00", "#0D1B2A", "#16A34A", "#7C3AED", "#DC2626", "#2563EB"];

function Avatar({ initials, size = 44, color }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: "50%", background: color || "#FF6B00",
      display: "flex", alignItems: "center", justifyContent: "center",
      color: "#fff", fontWeight: 700, fontSize: size * 0.32, flexShrink: 0,
      fontFamily: "system-ui"
    }}>{initials}</div>
  );
}

function Stars({ rating, size = 14 }) {
  return (
    <span style={{ color: "#F59E0B", fontSize: size }}>
      {"★".repeat(Math.floor(rating))}{"☆".repeat(5 - Math.floor(rating))}
      <span style={{ color: "#64748B", fontSize: size - 1, marginLeft: 4 }}>{rating}</span>
    </span>
  );
}

function Badge({ children, color = ORANGE }) {
  return (
    <span style={{
      background: color + "18", color, borderRadius: 20, padding: "2px 10px",
      fontSize: 11, fontWeight: 600, display: "inline-block"
    }}>{children}</span>
  );
}

function Btn({ children, variant = "primary", onClick, style = {} }) {
  const base = {
    borderRadius: 10, border: "none", cursor: "pointer", fontWeight: 600,
    transition: "all 0.18s", display: "inline-flex", alignItems: "center",
    gap: 6, fontSize: 13, padding: "9px 18px", ...style
  };
  if (variant === "primary") return <button onClick={onClick} style={{ ...base, background: ORANGE, color: "#fff" }}>{children}</button>;
  if (variant === "outline") return <button onClick={onClick} style={{ ...base, background: "transparent", color: ORANGE, border: `1.5px solid ${ORANGE}` }}>{children}</button>;
  if (variant === "dark") return <button onClick={onClick} style={{ ...base, background: DARK, color: "#fff" }}>{children}</button>;
  return <button onClick={onClick} style={{ ...base, background: "#F1F5F9", color: DARK }}>{children}</button>;
}

// ─── NAVBAR ───────────────────────────────────────────────────────────────────
function Navbar({ lang, setLang, setView, t, darkMode, setDarkMode }) {
  return (
    <nav style={{
      background: darkMode ? "#0D1B2A" : "#fff",
      borderBottom: `1px solid ${darkMode ? "#1e2d3d" : "#E2E8F0"}`,
      padding: "0 24px", height: 60, display: "flex", alignItems: "center",
      justifyContent: "space-between", position: "sticky", top: 0, zIndex: 100,
      direction: t.dir
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 32 }}>
        <div onClick={() => setView("home")} style={{ cursor: "pointer", display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{
            width: 34, height: 34, borderRadius: 10, background: ORANGE,
            display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 900, fontSize: 18
          }}>F</div>
          <span style={{ fontWeight: 800, fontSize: 20, color: ORANGE, letterSpacing: -0.5 }}>{t.name}</span>
        </div>
        <div style={{ display: "flex", gap: 4 }}>
          {[
            { key: "home", label: t.home },
            { key: "teachers", label: t.teachers },
            { key: "courses", label: t.courses },
            { key: "schools", label: t.schools },
          ].map(item => (
            <button key={item.key} onClick={() => setView(item.key)} style={{
              background: "none", border: "none", cursor: "pointer", padding: "6px 12px",
              borderRadius: 8, fontSize: 14, fontWeight: 500,
              color: darkMode ? "#CBD5E1" : "#475569",
              fontFamily: "inherit"
            }}>{item.label}</button>
          ))}
        </div>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <select
          value={lang}
          onChange={e => setLang(e.target.value)}
          style={{
            border: `1px solid #E2E8F0`, borderRadius: 8, padding: "5px 10px",
            fontSize: 13, cursor: "pointer", background: darkMode ? "#1e2d3d" : "#F8FAFC",
            color: darkMode ? "#E2E8F0" : DARK, outline: "none"
          }}
        >
          <option value="ku">کوردی</option>
          <option value="ar">عربي</option>
          <option value="en">English</option>
        </select>
        <button onClick={() => setDarkMode(!darkMode)} style={{
          background: "none", border: `1px solid #E2E8F0`, borderRadius: 8,
          padding: "5px 10px", cursor: "pointer", fontSize: 16,
          color: darkMode ? "#E2E8F0" : DARK
        }}>{darkMode ? "☀️" : "🌙"}</button>
        <Btn variant="outline" onClick={() => setView("login")} style={{ padding: "7px 14px", fontSize: 13 }}>{t.login}</Btn>
        <Btn onClick={() => setView("register")} style={{ padding: "7px 14px", fontSize: 13 }}>{t.register}</Btn>
      </div>
    </nav>
  );
}

// ─── HOME PAGE ────────────────────────────────────────────────────────────────
function HomePage({ t, lang, setView, darkMode }) {
  const [search, setSearch] = useState("");
  const bg = darkMode ? "#0a1628" : BG;
  const cardBg = darkMode ? "#0D1B2A" : "#fff";
  const textColor = darkMode ? "#E2E8F0" : DARK;
  const mutedColor = darkMode ? "#94A3B8" : "#64748B";
  const borderColor = darkMode ? "#1e2d3d" : "#E2E8F0";

  return (
    <div style={{ background: bg, minHeight: "100vh", direction: t.dir }}>
      {/* Hero */}
      <div style={{
        background: darkMode
          ? "linear-gradient(135deg, #0a1628 0%, #0D1B2A 50%, #1a2a3a 100%)"
          : "linear-gradient(135deg, #fff7f0 0%, #fff 50%, #f0f7ff 100%)",
        padding: "80px 24px 60px", textAlign: "center"
      }}>
        <div style={{
          display: "inline-flex", alignItems: "center", gap: 6,
          background: ORANGE + "18", borderRadius: 20, padding: "5px 14px",
          marginBottom: 20, fontSize: 13, fontWeight: 600, color: ORANGE
        }}>🎓 {lang === "ku" ? "پلاتفۆرمی پەروەردەی کوردستان" : lang === "ar" ? "منصة التعليم في كردستان" : "Kurdistan's Education Platform"}</div>
        <h1 style={{
          fontSize: 52, fontWeight: 900, color: textColor,
          margin: "0 0 16px", lineHeight: 1.1,
          letterSpacing: -2
        }}>
          {t.tagline.split(". ").map((w, i) => (
            <span key={i}>{i > 0 && ". "}<span style={i === 1 ? { color: ORANGE } : {}}>{w}</span></span>
          ))}
        </h1>
        <p style={{ fontSize: 18, color: mutedColor, marginBottom: 36 }}>{t.subtitle}</p>
        <div style={{
          maxWidth: 580, margin: "0 auto 32px",
          display: "flex", background: cardBg,
          borderRadius: 14, border: `1.5px solid ${borderColor}`,
          overflow: "hidden", boxShadow: "0 4px 24px rgba(0,0,0,0.07)"
        }}>
          <input
            value={search} onChange={e => setSearch(e.target.value)}
            placeholder={t.searchPlaceholder}
            style={{
              flex: 1, border: "none", padding: "14px 18px",
              fontSize: 15, outline: "none", background: "transparent",
              color: textColor, direction: t.dir
            }}
          />
          <button onClick={() => setView("teachers")} style={{
            background: ORANGE, color: "#fff", border: "none",
            padding: "0 24px", cursor: "pointer", fontWeight: 700, fontSize: 15,
            borderRadius: 0
          }}>{t.searchBtn}</button>
        </div>
        <div style={{ display: "flex", justifyContent: "center", gap: 24, flexWrap: "wrap" }}>
          {[
            { n: "1,250+", l: t.stats1 },
            { n: "12,540+", l: t.stats2 },
            { n: "320+", l: t.stats3 },
            { n: "45+", l: t.stats4 },
          ].map((s, i) => (
            <div key={i} style={{ textAlign: "center" }}>
              <div style={{ fontWeight: 800, fontSize: 24, color: ORANGE }}>{s.n}</div>
              <div style={{ fontSize: 13, color: mutedColor }}>{s.l}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px" }}>
        {/* Categories */}
        <Section title={t.categories} textColor={textColor}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12 }}>
            {categories.map((cat, i) => (
              <div key={i} onClick={() => setView("teachers")} style={{
                background: cardBg, borderRadius: 12, padding: "16px 14px",
                border: `1px solid ${borderColor}`, cursor: "pointer",
                display: "flex", alignItems: "center", gap: 10,
                transition: "all 0.2s",
              }}>
                <span style={{ fontSize: 24 }}>{cat.icon}</span>
                <span style={{ fontWeight: 600, fontSize: 13, color: textColor }}>
                  {lang === "ar" ? cat.labelAr : lang === "ku" ? cat.labelKu : cat.label}
                </span>
              </div>
            ))}
          </div>
        </Section>

        {/* Popular Teachers */}
        <Section title={t.popularTeachers} textColor={textColor} action={{ label: t.allTeachers, onClick: () => setView("teachers") }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
            {teachers.map(t2 => (
              <TeacherCard key={t2.id} teacher={t2} lang={lang} t={t} cardBg={cardBg} textColor={textColor} mutedColor={mutedColor} borderColor={borderColor} setView={setView} />
            ))}
          </div>
        </Section>

        {/* Featured Courses */}
        <Section title={t.featuredCourses} textColor={textColor}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
            {courses.map(c => (
              <CourseCard key={c.id} course={c} lang={lang} t={t} cardBg={cardBg} textColor={textColor} mutedColor={mutedColor} borderColor={borderColor} setView={setView} />
            ))}
          </div>
        </Section>

        {/* Featured Schools */}
        <Section title={t.featuredSchools} textColor={textColor}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
            {schools.map(s => (
              <SchoolCard key={s.id} school={s} lang={lang} t={t} cardBg={cardBg} textColor={textColor} mutedColor={mutedColor} borderColor={borderColor} />
            ))}
          </div>
        </Section>

        {/* CTA */}
        <div style={{
          background: `linear-gradient(135deg, ${ORANGE} 0%, #e55a00 100%)`,
          borderRadius: 20, padding: "48px 40px", textAlign: "center",
          margin: "40px 0 60px"
        }}>
          <h2 style={{ color: "#fff", fontSize: 32, fontWeight: 800, margin: "0 0 12px" }}>{t.cta}</h2>
          <p style={{ color: "rgba(255,255,255,0.85)", marginBottom: 28, fontSize: 16 }}>
            {lang === "ku" ? "بەخۆڕایی تۆمار بکە و دەست بکە بە فێربوون" : lang === "ar" ? "سجل مجاناً وابدأ التعلم اليوم" : "Register for free and start learning today"}
          </p>
          <button onClick={() => setView("register")} style={{
            background: "#fff", color: ORANGE, border: "none", borderRadius: 10,
            padding: "14px 36px", fontWeight: 700, fontSize: 16, cursor: "pointer"
          }}>{t.ctaBtn}</button>
        </div>
      </div>

      {/* Footer */}
      <div style={{
        background: DARK, color: "#94A3B8", textAlign: "center",
        padding: "20px 24px", fontSize: 13, direction: t.dir
      }}>{t.footer}</div>
    </div>
  );
}

function Section({ title, textColor, children, action }) {
  return (
    <div style={{ margin: "48px 0 0" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h2 style={{ fontSize: 22, fontWeight: 800, color: textColor, margin: 0 }}>{title}</h2>
        {action && <button onClick={action.onClick} style={{ background: "none", border: "none", color: ORANGE, fontWeight: 600, cursor: "pointer", fontSize: 14 }}>{action.label} →</button>}
      </div>
      {children}
    </div>
  );
}

function TeacherCard({ teacher, lang, t, cardBg, textColor, mutedColor, borderColor, setView }) {
  const name = lang === "ar" ? teacher.nameAr : lang === "ku" ? teacher.nameKu : teacher.name;
  return (
    <div style={{
      background: cardBg, borderRadius: 16, border: `1px solid ${borderColor}`,
      padding: 18, transition: "all 0.2s", cursor: "pointer"
    }} onClick={() => setView("teacherProfile")}>
      <div style={{ textAlign: "center", marginBottom: 14 }}>
        <div style={{ position: "relative", display: "inline-block" }}>
          <Avatar initials={teacher.img} size={64} color={teacher.color} />
          {teacher.online && (
            <div style={{
              position: "absolute", bottom: 2, right: 2, width: 12, height: 12,
              borderRadius: "50%", background: "#22C55E", border: "2px solid #fff"
            }} />
          )}
        </div>
        <h3 style={{ fontWeight: 700, fontSize: 15, margin: "10px 0 2px", color: textColor }}>{name}</h3>
        <p style={{ fontSize: 12, color: mutedColor, margin: 0 }}>{teacher.subject}</p>
        <div style={{ margin: "6px 0" }}><Stars rating={teacher.rating} /></div>
        <p style={{ fontSize: 11, color: mutedColor, margin: 0 }}>({teacher.reviews} {t.reviews})</p>
      </div>
      <div style={{ borderTop: `1px solid ${borderColor}`, paddingTop: 12, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={{ fontSize: 16, fontWeight: 800, color: ORANGE }}>{teacher.price.toLocaleString()} IQD</div>
          <div style={{ fontSize: 11, color: mutedColor }}>{t.perHour}</div>
        </div>
        <Btn style={{ padding: "7px 12px", fontSize: 12 }}>{t.bookSession}</Btn>
      </div>
    </div>
  );
}

function CourseCard({ course, lang, t, cardBg, textColor, mutedColor, borderColor, setView }) {
  const title = lang === "ar" ? course.titleAr : lang === "ku" ? course.titleKu : course.title;
  return (
    <div style={{
      background: cardBg, borderRadius: 16, border: `1px solid ${borderColor}`,
      overflow: "hidden", cursor: "pointer", transition: "all 0.2s"
    }} onClick={() => setView("courseDetail")}>
      <div style={{
        height: 100, background: `linear-gradient(135deg, ${course.color} 0%, ${course.color}cc 100%)`,
        display: "flex", alignItems: "center", justifyContent: "center", fontSize: 36
      }}>📚</div>
      <div style={{ padding: 14 }}>
        <h3 style={{ fontWeight: 700, fontSize: 14, margin: "0 0 4px", color: textColor }}>{title}</h3>
        <div style={{ marginBottom: 8 }}><Stars rating={course.rating} size={12} /></div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ fontWeight: 800, fontSize: 15, color: ORANGE }}>{course.price.toLocaleString()} IQD</span>
          <Badge>{course.level}</Badge>
        </div>
      </div>
    </div>
  );
}

function SchoolCard({ school, lang, t, cardBg, textColor, mutedColor, borderColor }) {
  const name = lang === "ar" ? school.nameAr : lang === "ku" ? school.nameKu : school.name;
  return (
    <div style={{ background: cardBg, borderRadius: 16, border: `1px solid ${borderColor}`, padding: 18 }}>
      <div style={{ display: "flex", gap: 12, marginBottom: 12 }}>
        <div style={{
          width: 48, height: 48, borderRadius: 10, background: ORANGE + "18",
          display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, flexShrink: 0
        }}>🏫</div>
        <div>
          <h3 style={{ fontWeight: 700, fontSize: 14, margin: "0 0 2px", color: textColor }}>{name}</h3>
          <p style={{ fontSize: 12, color: mutedColor, margin: 0 }}>📍 {lang === "ku" ? school.location.replace("Kurdistan", "کوردستان") : school.location}</p>
          <Stars rating={school.rating} size={11} />
        </div>
      </div>
      <div style={{ display: "flex", gap: 8 }}>
        <Btn variant="outline" style={{ flex: 1, justifyContent: "center", padding: "7px 0", fontSize: 12 }}>{t.message}</Btn>
        <Btn style={{ flex: 1, justifyContent: "center", padding: "7px 0", fontSize: 12 }}>{t.viewProfile}</Btn>
      </div>
    </div>
  );
}

// ─── TEACHER PROFILE PAGE ──────────────────────────────────────────────────────
function TeacherProfilePage({ t, lang, darkMode, setView }) {
  const cardBg = darkMode ? "#0D1B2A" : "#fff";
  const textColor = darkMode ? "#E2E8F0" : DARK;
  const mutedColor = darkMode ? "#94A3B8" : "#64748B";
  const borderColor = darkMode ? "#1e2d3d" : "#E2E8F0";
  const bg = darkMode ? "#0a1628" : BG;
  const teacher = teachers[0];

  return (
    <div style={{ background: bg, minHeight: "100vh", direction: t.dir, padding: "32px 24px" }}>
      <div style={{ maxWidth: 900, margin: "0 auto" }}>
        <button onClick={() => setView("teachers")} style={{
          background: "none", border: "none", color: ORANGE, cursor: "pointer",
          fontWeight: 600, marginBottom: 24, fontSize: 14, display: "flex", alignItems: "center", gap: 6
        }}>← {t.teachers}</button>

        <div style={{ display: "grid", gridTemplateColumns: "300px 1fr", gap: 24 }}>
          {/* Sidebar */}
          <div>
            <div style={{ background: cardBg, borderRadius: 16, border: `1px solid ${borderColor}`, padding: 24, textAlign: "center", marginBottom: 16 }}>
              <div style={{ position: "relative", display: "inline-block", marginBottom: 12 }}>
                <Avatar initials="ZA" size={90} color={ORANGE} />
                <div style={{ position: "absolute", bottom: 4, right: 4, background: "#22C55E", color: "#fff", fontSize: 9, padding: "2px 6px", borderRadius: 10, fontWeight: 700 }}>LIVE</div>
              </div>
              <h2 style={{ fontWeight: 800, fontSize: 20, margin: "0 0 4px", color: textColor }}>
                {lang === "ku" ? "زانا ئەحمەد" : lang === "ar" ? "زانا أحمد" : "Zana Ahmed"}
              </h2>
              <p style={{ color: mutedColor, fontSize: 13, margin: "0 0 8px" }}>
                {lang === "ku" ? "مامۆستای ئینگلیزی" : lang === "ar" ? "معلمة اللغة الإنجليزية" : "English Language Teacher"}
              </p>
              <div style={{ marginBottom: 10 }}><Stars rating={4.8} /></div>
              <div style={{ display: "flex", justifyContent: "center", gap: 16, marginBottom: 16, fontSize: 13, color: mutedColor }}>
                <span>320 {t.reviews}</span>
                <span>4 {t.years}</span>
              </div>
              <div style={{ background: ORANGE + "12", borderRadius: 10, padding: "12px 0", marginBottom: 16 }}>
                <div style={{ fontWeight: 800, fontSize: 22, color: ORANGE }}>15,000 IQD</div>
                <div style={{ fontSize: 12, color: mutedColor }}>{t.perHour}</div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <Btn style={{ width: "100%", justifyContent: "center" }} onClick={() => setView("booking")}>{t.bookSession}</Btn>
                <Btn variant="outline" style={{ width: "100%", justifyContent: "center" }}>{t.message}</Btn>
              </div>
            </div>

            <div style={{ background: cardBg, borderRadius: 16, border: `1px solid ${borderColor}`, padding: 18 }}>
              <h4 style={{ fontWeight: 700, fontSize: 14, color: textColor, margin: "0 0 12px" }}>{t.subjects}</h4>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                {["IELTS", "TOEFL", "English", "Conversation"].map(s => <Badge key={s}>{s}</Badge>)}
              </div>
            </div>
          </div>

          {/* Main */}
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div style={{ background: cardBg, borderRadius: 16, border: `1px solid ${borderColor}`, padding: 24 }}>
              <h3 style={{ fontWeight: 700, fontSize: 16, color: textColor, margin: "0 0 12px" }}>
                {lang === "ku" ? "دەربارەی من" : lang === "ar" ? "عني" : "About Me"}
              </h3>
              <p style={{ color: mutedColor, lineHeight: 1.7, fontSize: 14 }}>
                {lang === "ku"
                  ? "مامۆستایەکی ئینگلیزیم بە ٤ ساڵ ئەزموون لە ئامادەکردنی خوێندکار بۆ ئامۆژگاری IELTS و TOEFL. زۆر خوشحاڵم لە یارمەتیدانی خوێندکاران لە باشترکردنی قسەکردن، خوێندن و نووسین."
                  : lang === "ar"
                  ? "معلمة لغة إنجليزية بخبرة 4 سنوات في تحضير الطلاب لامتحانات IELTS وTOEFL. أحب مساعدة الطلاب على تحسين مهاراتهم في المحادثة والقراءة والكتابة."
                  : "English language teacher with 4 years experience preparing students for IELTS & TOEFL. Passionate about helping students improve speaking, reading and writing skills."}
              </p>
            </div>

            <div style={{ background: cardBg, borderRadius: 16, border: `1px solid ${borderColor}`, padding: 24 }}>
              <h3 style={{ fontWeight: 700, fontSize: 16, color: textColor, margin: "0 0 16px" }}>
                {lang === "ku" ? "بەروارنامەکان" : lang === "ar" ? "الشهادات" : "Certificates"}
              </h3>
              {["TOEFL Certificate", "IELTS Certificate", "Cambridge CELTA"].map(cert => (
                <div key={cert} style={{
                  display: "flex", alignItems: "center", gap: 10,
                  padding: "10px 0", borderBottom: `1px solid ${borderColor}`
                }}>
                  <div style={{ width: 32, height: 32, borderRadius: 8, background: ORANGE + "18", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>🏅</div>
                  <span style={{ fontSize: 14, color: textColor, fontWeight: 500 }}>{cert}</span>
                  <Badge color="#16A34A">✓ Verified</Badge>
                </div>
              ))}
            </div>

            {/* Reviews */}
            <div style={{ background: cardBg, borderRadius: 16, border: `1px solid ${borderColor}`, padding: 24 }}>
              <h3 style={{ fontWeight: 700, fontSize: 16, color: textColor, margin: "0 0 16px" }}>{t.reviews}</h3>
              <div style={{ display: "flex", gap: 24, marginBottom: 20 }}>
                <div style={{ textAlign: "center" }}>
                  <div style={{ fontSize: 48, fontWeight: 900, color: ORANGE }}>4.8</div>
                  <Stars rating={4.8} size={18} />
                  <div style={{ fontSize: 12, color: mutedColor, marginTop: 4 }}>320 {t.reviews}</div>
                </div>
                <div style={{ flex: 1 }}>
                  {[5, 4, 3, 2, 1].map((star, i) => {
                    const pct = [85, 10, 3, 1, 1][i];
                    return (
                      <div key={star} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                        <span style={{ fontSize: 12, color: mutedColor, width: 12 }}>{star}</span>
                        <div style={{ flex: 1, height: 6, background: "#F1F5F9", borderRadius: 4 }}>
                          <div style={{ height: "100%", width: `${pct}%`, background: ORANGE, borderRadius: 4 }} />
                        </div>
                        <span style={{ fontSize: 12, color: mutedColor, width: 28 }}>{pct}%</span>
                      </div>
                    );
                  })}
                </div>
              </div>
              {[
                { name: "Sara J.", text: lang === "ku" ? "مامۆستایەکی زۆر باشە!" : lang === "ar" ? "معلمة رائعة جداً!" : "An amazing teacher!", rating: 5 },
                { name: "Ali H.", text: lang === "ku" ? "زۆر یارمەتیدەرم بوو" : lang === "ar" ? "كانت مفيدة جداً" : "Very helpful and patient", rating: 5 },
              ].map((rev, i) => (
                <div key={i} style={{ borderTop: `1px solid ${borderColor}`, paddingTop: 14, marginTop: 14 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <Avatar initials={rev.name.slice(0, 2)} size={32} color={avatarColors[i]} />
                      <span style={{ fontWeight: 600, fontSize: 14, color: textColor }}>{rev.name}</span>
                    </div>
                    <Stars rating={rev.rating} size={12} />
                  </div>
                  <p style={{ fontSize: 13, color: mutedColor, margin: 0 }}>{rev.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── BOOKING PAGE ──────────────────────────────────────────────────────────────
function BookingPage({ t, lang, darkMode, setView }) {
  const cardBg = darkMode ? "#0D1B2A" : "#fff";
  const textColor = darkMode ? "#E2E8F0" : DARK;
  const mutedColor = darkMode ? "#94A3B8" : "#64748B";
  const borderColor = darkMode ? "#1e2d3d" : "#E2E8F0";
  const bg = darkMode ? "#0a1628" : BG;
  const [selectedDate, setSelectedDate] = useState(20);
  const [selectedTime, setSelectedTime] = useState("10:00 AM");
  const [mode, setMode] = useState("online");
  const [duration, setDuration] = useState(60);
  const [confirmed, setConfirmed] = useState(false);

  const times = ["09:00 AM", "10:00 AM", "11:00 AM", "01:00 PM", "02:00 PM", "03:00 PM", "04:00 PM", "05:00 PM"];
  const days = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
  const price = Math.round((duration / 60) * 15000);

  if (confirmed) {
    return (
      <div style={{ background: bg, minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", direction: t.dir }}>
        <div style={{ background: cardBg, borderRadius: 20, padding: 40, textAlign: "center", maxWidth: 400, width: "100%", border: `1px solid ${borderColor}` }}>
          <div style={{ width: 72, height: 72, borderRadius: "50%", background: "#22C55E18", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 36, margin: "0 auto 20px" }}>✅</div>
          <h2 style={{ fontWeight: 800, fontSize: 22, color: textColor, margin: "0 0 8px" }}>
            {lang === "ku" ? "داواکاری نێردرا!" : lang === "ar" ? "تم إرسال الطلب!" : "Request Sent!"}
          </h2>
          <p style={{ color: mutedColor, marginBottom: 24, fontSize: 14 }}>
            {lang === "ku" ? "داواکارییەکەت نێردرا بۆ زانا ئەحمەد" : lang === "ar" ? "تم إرسال طلبك إلى زانا أحمد" : "Your booking request has been sent to Zana Ahmed"}
          </p>
          <div style={{ background: bg, borderRadius: 12, padding: 16, marginBottom: 24, textAlign: t.dir === "rtl" ? "right" : "left" }}>
            {[
              { l: lang === "ku" ? "بەروار" : lang === "ar" ? "التاريخ" : "Date", v: `Tuesday, 20 May 2025` },
              { l: lang === "ku" ? "کات" : lang === "ar" ? "الوقت" : "Time", v: selectedTime },
              { l: lang === "ku" ? "ماوە" : lang === "ar" ? "المدة" : "Duration", v: `${duration} min` },
              { l: lang === "ku" ? "نرخ" : lang === "ar" ? "السعر" : "Price", v: `${price.toLocaleString()} IQD` },
            ].map(row => (
              <div key={row.l} style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderBottom: `1px solid ${borderColor}`, fontSize: 14 }}>
                <span style={{ color: mutedColor }}>{row.l}</span>
                <span style={{ fontWeight: 600, color: textColor }}>{row.v}</span>
              </div>
            ))}
          </div>
          <Btn onClick={() => { setConfirmed(false); setView("studentDashboard"); }} style={{ width: "100%", justifyContent: "center" }}>
            {lang === "ku" ? "پشکنینەکانم" : lang === "ar" ? "حجوزاتي" : "View My Bookings"}
          </Btn>
        </div>
      </div>
    );
  }

  return (
    <div style={{ background: bg, minHeight: "100vh", direction: t.dir, padding: "32px 24px" }}>
      <div style={{ maxWidth: 600, margin: "0 auto" }}>
        <button onClick={() => setView("teacherProfile")} style={{ background: "none", border: "none", color: ORANGE, cursor: "pointer", fontWeight: 600, marginBottom: 24, fontSize: 14 }}>
          ← {lang === "ku" ? "گەڕانەوە" : lang === "ar" ? "رجوع" : "Back"}
        </button>
        <div style={{ background: cardBg, borderRadius: 20, border: `1px solid ${borderColor}`, padding: 28 }}>
          <h2 style={{ fontWeight: 800, fontSize: 22, color: textColor, margin: "0 0 24px" }}>
            {lang === "ku" ? "پۆل پشکنین" : lang === "ar" ? "احجز جلسة" : "Book a Session"}
          </h2>

          {/* Mode */}
          <div style={{ marginBottom: 24 }}>
            <label style={{ fontSize: 13, fontWeight: 600, color: mutedColor, display: "block", marginBottom: 8 }}>
              {lang === "ku" ? "جۆری پۆل" : lang === "ar" ? "نوع الجلسة" : "Session Type"}
            </label>
            <div style={{ display: "flex", gap: 10 }}>
              {["online", "offline"].map(m => (
                <button key={m} onClick={() => setMode(m)} style={{
                  flex: 1, padding: "10px 0", borderRadius: 10, cursor: "pointer", fontWeight: 600, fontSize: 14,
                  background: mode === m ? ORANGE : "transparent",
                  color: mode === m ? "#fff" : mutedColor,
                  border: `1.5px solid ${mode === m ? ORANGE : borderColor}`,
                  transition: "all 0.18s"
                }}>
                  {m === "online" ? (lang === "ku" ? "ئۆنلاین" : lang === "ar" ? "أونلاين" : "Online") : (lang === "ku" ? "ئۆفلاین" : lang === "ar" ? "حضوري" : "In-Person")}
                </button>
              ))}
            </div>
          </div>

          {/* Calendar */}
          <div style={{ marginBottom: 24 }}>
            <label style={{ fontSize: 13, fontWeight: 600, color: mutedColor, display: "block", marginBottom: 8 }}>
              {lang === "ku" ? "بەروار هەڵبژاردن" : lang === "ar" ? "اختر التاريخ" : "Select Date"}
            </label>
            <div style={{ background: bg, borderRadius: 12, padding: 16 }}>
              <div style={{ textAlign: "center", fontWeight: 700, fontSize: 15, color: textColor, marginBottom: 12 }}>May 2025</div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 4, marginBottom: 8 }}>
                {days.map(d => <div key={d} style={{ textAlign: "center", fontSize: 11, color: mutedColor, fontWeight: 600 }}>{d}</div>)}
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 4 }}>
                {Array.from({ length: 31 }, (_, i) => i + 1).map(d => (
                  <button key={d} onClick={() => setSelectedDate(d)} style={{
                    padding: "7px 0", borderRadius: 8, border: "none", cursor: "pointer", fontSize: 13,
                    fontWeight: selectedDate === d ? 700 : 400,
                    background: selectedDate === d ? ORANGE : "transparent",
                    color: selectedDate === d ? "#fff" : [6, 13, 14, 20, 27, 28].includes(d) ? "#CBD5E1" : textColor,
                    transition: "all 0.15s"
                  }}>{d}</button>
                ))}
              </div>
            </div>
          </div>

          {/* Time */}
          <div style={{ marginBottom: 24 }}>
            <label style={{ fontSize: 13, fontWeight: 600, color: mutedColor, display: "block", marginBottom: 8 }}>
              {lang === "ku" ? "کات هەڵبژاردن" : lang === "ar" ? "اختر الوقت" : "Select Time"}
            </label>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8 }}>
              {times.map(time => (
                <button key={time} onClick={() => setSelectedTime(time)} style={{
                  padding: "9px 0", borderRadius: 8, border: `1.5px solid ${selectedTime === time ? ORANGE : borderColor}`,
                  background: selectedTime === time ? ORANGE + "15" : "transparent",
                  color: selectedTime === time ? ORANGE : textColor,
                  cursor: "pointer", fontSize: 12, fontWeight: selectedTime === time ? 700 : 400,
                  transition: "all 0.15s"
                }}>{time}</button>
              ))}
            </div>
          </div>

          {/* Duration */}
          <div style={{ marginBottom: 24 }}>
            <label style={{ fontSize: 13, fontWeight: 600, color: mutedColor, display: "block", marginBottom: 8 }}>
              {lang === "ku" ? "ماوە" : lang === "ar" ? "المدة" : "Duration"}
            </label>
            <div style={{ display: "flex", gap: 8 }}>
              {[30, 60, 90].map(d => (
                <button key={d} onClick={() => setDuration(d)} style={{
                  flex: 1, padding: "9px 0", borderRadius: 8, border: `1.5px solid ${duration === d ? ORANGE : borderColor}`,
                  background: duration === d ? ORANGE + "15" : "transparent",
                  color: duration === d ? ORANGE : textColor,
                  cursor: "pointer", fontSize: 13, fontWeight: duration === d ? 700 : 400,
                  transition: "all 0.15s"
                }}>{d} {lang === "ku" ? "خولەک" : lang === "ar" ? "دقيقة" : "min"}</button>
              ))}
            </div>
          </div>

          {/* Summary */}
          <div style={{ background: ORANGE + "0d", borderRadius: 12, padding: 16, marginBottom: 20, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <div style={{ fontSize: 12, color: mutedColor }}>{lang === "ku" ? "کۆی نرخ" : lang === "ar" ? "إجمالي السعر" : "Total Price"}</div>
              <div style={{ fontSize: 24, fontWeight: 900, color: ORANGE }}>{price.toLocaleString()} IQD</div>
            </div>
            <div style={{ fontSize: 13, color: mutedColor }}>
              {selectedDate} May · {selectedTime} · {duration}min
            </div>
          </div>

          <Btn onClick={() => setConfirmed(true)} style={{ width: "100%", justifyContent: "center", padding: "14px 0", fontSize: 15 }}>
            {lang === "ku" ? "پشکنینەکە بنێرە" : lang === "ar" ? "أرسل الطلب" : "Send Request"}
          </Btn>
        </div>
      </div>
    </div>
  );
}

// ─── TEACHERS LIST PAGE ────────────────────────────────────────────────────────
function TeachersPage({ t, lang, darkMode, setView }) {
  const cardBg = darkMode ? "#0D1B2A" : "#fff";
  const textColor = darkMode ? "#E2E8F0" : DARK;
  const mutedColor = darkMode ? "#94A3B8" : "#64748B";
  const borderColor = darkMode ? "#1e2d3d" : "#E2E8F0";
  const bg = darkMode ? "#0a1628" : BG;
  const [filter, setFilter] = useState({ online: false, offline: false, subject: "all" });

  return (
    <div style={{ background: bg, minHeight: "100vh", direction: t.dir, padding: "32px 24px" }}>
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        <h1 style={{ fontSize: 28, fontWeight: 800, color: textColor, marginBottom: 24 }}>{t.teachers}</h1>
        <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", gap: 24 }}>
          {/* Filters */}
          <div style={{ background: cardBg, borderRadius: 16, border: `1px solid ${borderColor}`, padding: 20, height: "fit-content" }}>
            <h3 style={{ fontWeight: 700, fontSize: 15, color: textColor, margin: "0 0 16px" }}>{t.filter}</h3>
            {[
              { label: lang === "ku" ? "بابەت" : lang === "ar" ? "المادة" : "Subject", options: ["All", "English", "Math", "Science", "Programming"] },
              { label: lang === "ku" ? "جۆر" : lang === "ar" ? "النوع" : "Type", options: ["All", t.online, t.offline] },
              { label: lang === "ku" ? "نرخ" : lang === "ar" ? "السعر" : "Price", options: ["All", "< 10,000 IQD", "10K-20K IQD", "> 20,000 IQD"] },
            ].map(f => (
              <div key={f.label} style={{ marginBottom: 20 }}>
                <label style={{ fontSize: 13, fontWeight: 600, color: mutedColor, display: "block", marginBottom: 8 }}>{f.label}</label>
                <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                  {f.options.map(opt => (
                    <label key={opt} style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 13, color: textColor }}>
                      <input type="radio" name={f.label} style={{ accentColor: ORANGE }} />
                      {opt}
                    </label>
                  ))}
                </div>
              </div>
            ))}
            <Btn style={{ width: "100%", justifyContent: "center" }}>{t.filter}</Btn>
          </div>

          {/* Results */}
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <span style={{ fontSize: 14, color: mutedColor }}>
                {lang === "ku" ? "٤ مامۆستا دۆزراوەتەوە" : lang === "ar" ? "تم العثور على 4 معلمين" : "4 teachers found"}
              </span>
              <select style={{ border: `1px solid ${borderColor}`, borderRadius: 8, padding: "6px 10px", fontSize: 13, background: cardBg, color: textColor }}>
                <option>{lang === "ku" ? "باشترین هەڵسەنگاندن" : lang === "ar" ? "الأعلى تقييماً" : "Highest Rated"}</option>
                <option>{lang === "ku" ? "کەمترین نرخ" : lang === "ar" ? "الأقل سعراً" : "Lowest Price"}</option>
              </select>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {teachers.map(teacher => {
                const name = lang === "ar" ? teacher.nameAr : lang === "ku" ? teacher.nameKu : teacher.name;
                return (
                  <div key={teacher.id} style={{
                    background: cardBg, borderRadius: 16, border: `1px solid ${borderColor}`,
                    padding: 20, display: "flex", gap: 18, alignItems: "center"
                  }}>
                    <Avatar initials={teacher.img} size={68} color={teacher.color} />
                    <div style={{ flex: 1 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                        <h3 style={{ fontWeight: 700, fontSize: 16, color: textColor, margin: 0 }}>{name}</h3>
                        <Badge color="#22C55E">{teacher.online ? t.online : t.offline}</Badge>
                      </div>
                      <p style={{ fontSize: 13, color: mutedColor, margin: "0 0 8px" }}>{teacher.subject}</p>
                      <Stars rating={teacher.rating} />
                      <span style={{ fontSize: 12, color: mutedColor, marginLeft: 8 }}>({teacher.reviews})</span>
                    </div>
                    <div style={{ textAlign: "center" }}>
                      <div style={{ fontSize: 20, fontWeight: 800, color: ORANGE }}>{teacher.price.toLocaleString()}</div>
                      <div style={{ fontSize: 11, color: mutedColor }}>IQD {t.perHour}</div>
                    </div>
                    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                      <Btn onClick={() => setView("teacherProfile")} style={{ padding: "8px 16px", fontSize: 13 }}>{t.bookSession}</Btn>
                      <Btn variant="outline" style={{ padding: "8px 16px", fontSize: 13 }}>{t.viewProfile}</Btn>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── STUDENT DASHBOARD ─────────────────────────────────────────────────────────
function StudentDashboard({ t, lang, darkMode }) {
  const cardBg = darkMode ? "#0D1B2A" : "#fff";
  const textColor = darkMode ? "#E2E8F0" : DARK;
  const mutedColor = darkMode ? "#94A3B8" : "#64748B";
  const borderColor = darkMode ? "#1e2d3d" : "#E2E8F0";
  const bg = darkMode ? "#0a1628" : BG;
  const [tab, setTab] = useState("upcoming");

  const bookings = [
    { teacher: lang === "ku" ? "زانا ئەحمەد" : lang === "ar" ? "زانا أحمد" : "Zana Ahmed", subject: "English", date: "20 May 2025 · 10:00 AM", status: "upcoming", mode: t.online, initials: "ZA", color: ORANGE },
    { teacher: lang === "ku" ? "هانا کەریم" : lang === "ar" ? "هنا كريم" : "Hana Karim", subject: "IELTS Prep", date: "22 May 2025 · 04:00 PM", status: "upcoming", mode: t.online, initials: "HK", color: DARK },
    { teacher: lang === "ku" ? "عەلی حەسەن" : lang === "ar" ? "علي حسن" : "Ali Hassan", subject: "Math", date: "25 May 2025 · 11:00 AM", status: "pending", mode: t.offline, initials: "AH", color: "#16A34A" },
  ];

  const savedTeachers = teachers.slice(0, 3);

  return (
    <div style={{ background: bg, minHeight: "100vh", direction: t.dir }}>
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "32px 24px" }}>
        <h1 style={{ fontSize: 26, fontWeight: 800, color: textColor, marginBottom: 8 }}>
          {lang === "ku" ? "خێر بێیت، زانا! 👋" : lang === "ar" ? "مرحباً، زانا! 👋" : "Welcome back, Zana! 👋"}
        </h1>
        <p style={{ color: mutedColor, marginBottom: 28 }}>
          {lang === "ku" ? "ئەمڕۆ چی فێر دەبیت؟" : lang === "ar" ? "ماذا ستتعلم اليوم؟" : "What are you learning today?"}
        </p>

        {/* Stats */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 28 }}>
          {[
            { label: lang === "ku" ? "پشکنینەکان" : lang === "ar" ? "الحجوزات" : "Bookings", value: "12", icon: "📅", color: ORANGE },
            { label: lang === "ku" ? "کۆرسەکان" : lang === "ar" ? "الدورات" : "Courses", value: "3", icon: "📚", color: "#7C3AED" },
            { label: lang === "ku" ? "کاتژمێر" : lang === "ar" ? "ساعات التعلم" : "Hours Learned", value: "24", icon: "⏱️", color: "#16A34A" },
            { label: lang === "ku" ? "جەخت" : lang === "ar" ? "الرصيد" : "Wallet", value: "25,000", icon: "💰", color: "#2563EB" },
          ].map(stat => (
            <div key={stat.label} style={{ background: cardBg, borderRadius: 14, border: `1px solid ${borderColor}`, padding: 18 }}>
              <div style={{ fontSize: 26, marginBottom: 8 }}>{stat.icon}</div>
              <div style={{ fontSize: 22, fontWeight: 800, color: stat.color }}>{stat.value}{stat.label === (lang === "ku" ? "جەخت" : lang === "ar" ? "الرصيد" : "Wallet") ? " IQD" : ""}</div>
              <div style={{ fontSize: 12, color: mutedColor, marginTop: 2 }}>{stat.label}</div>
            </div>
          ))}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 20 }}>
          {/* Bookings */}
          <div style={{ background: cardBg, borderRadius: 16, border: `1px solid ${borderColor}`, padding: 22 }}>
            <h3 style={{ fontWeight: 700, fontSize: 16, color: textColor, margin: "0 0 16px" }}>
              {lang === "ku" ? "پشکنینەکانم" : lang === "ar" ? "حجوزاتي" : "My Bookings"}
            </h3>
            <div style={{ display: "flex", gap: 6, marginBottom: 18 }}>
              {["upcoming", "pending", "completed"].map(s => (
                <button key={s} onClick={() => setTab(s)} style={{
                  padding: "6px 14px", borderRadius: 8, border: "none", cursor: "pointer",
                  fontSize: 12, fontWeight: 600, transition: "all 0.15s",
                  background: tab === s ? ORANGE : "transparent",
                  color: tab === s ? "#fff" : mutedColor
                }}>
                  {s === "upcoming" ? (lang === "ku" ? "داهاتوو" : lang === "ar" ? "القادمة" : "Upcoming") :
                    s === "pending" ? (lang === "ku" ? "چاوەڕوان" : lang === "ar" ? "معلقة" : "Pending") :
                      (lang === "ku" ? "تەواوبوو" : lang === "ar" ? "مكتملة" : "Completed")}
                </button>
              ))}
            </div>
            {bookings.filter(b => tab === "upcoming" ? b.status === "upcoming" : b.status === tab || tab === "upcoming").map((b, i) => (
              <div key={i} style={{
                display: "flex", gap: 14, alignItems: "center",
                padding: "14px 0", borderBottom: `1px solid ${borderColor}`
              }}>
                <Avatar initials={b.initials} size={46} color={b.color} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontSize: 14, color: textColor }}>{b.teacher}</div>
                  <div style={{ fontSize: 12, color: mutedColor }}>{b.subject} · {b.date}</div>
                  <div style={{ marginTop: 4 }}><Badge color={b.mode === t.online ? "#2563EB" : "#16A34A"}>{b.mode}</Badge></div>
                </div>
                <Badge color={b.status === "upcoming" ? "#22C55E" : b.status === "pending" ? "#F59E0B" : "#64748B"}>
                  {b.status === "upcoming" ? (lang === "ku" ? "داهاتوو" : "Upcoming") : b.status === "pending" ? (lang === "ku" ? "چاوەڕوان" : "Pending") : (lang === "ku" ? "تەواو" : "Done")}
                </Badge>
              </div>
            ))}
          </div>

          {/* Saved Teachers */}
          <div style={{ background: cardBg, borderRadius: 16, border: `1px solid ${borderColor}`, padding: 22 }}>
            <h3 style={{ fontWeight: 700, fontSize: 16, color: textColor, margin: "0 0 16px" }}>
              {lang === "ku" ? "مامۆستا پاراستراوەکان" : lang === "ar" ? "المعلمون المحفوظون" : "Saved Teachers"}
            </h3>
            {savedTeachers.map((teacher, i) => {
              const name = lang === "ar" ? teacher.nameAr : lang === "ku" ? teacher.nameKu : teacher.name;
              return (
                <div key={i} style={{
                  display: "flex", alignItems: "center", gap: 10,
                  padding: "12px 0", borderBottom: `1px solid ${borderColor}`
                }}>
                  <Avatar initials={teacher.img} size={40} color={teacher.color} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: 13, color: textColor }}>{name}</div>
                    <div style={{ fontSize: 11, color: mutedColor }}>{teacher.subject}</div>
                    <Stars rating={teacher.rating} size={11} />
                  </div>
                  <button style={{ background: "none", border: "none", cursor: "pointer", fontSize: 18, color: "#EF4444" }}>♥</button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Saved Courses */}
        <div style={{ background: cardBg, borderRadius: 16, border: `1px solid ${borderColor}`, padding: 22, marginTop: 20 }}>
          <h3 style={{ fontWeight: 700, fontSize: 16, color: textColor, margin: "0 0 16px" }}>
            {lang === "ku" ? "کۆرسە پاراستراوەکان" : lang === "ar" ? "الدورات المحفوظة" : "Saved Courses"}
          </h3>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14 }}>
            {courses.slice(0, 3).map(c => {
              const title = lang === "ar" ? c.titleAr : lang === "ku" ? c.titleKu : c.title;
              return (
                <div key={c.id} style={{
                  borderRadius: 12, border: `1px solid ${borderColor}`,
                  overflow: "hidden", background: bg
                }}>
                  <div style={{ height: 64, background: c.color, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24 }}>📚</div>
                  <div style={{ padding: 12 }}>
                    <div style={{ fontWeight: 700, fontSize: 13, color: textColor, marginBottom: 4 }}>{title}</div>
                    <Stars rating={c.rating} size={11} />
                    <div style={{ fontWeight: 800, fontSize: 14, color: ORANGE, marginTop: 6 }}>{c.price.toLocaleString()} IQD</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── TEACHER DASHBOARD ─────────────────────────────────────────────────────────
function TeacherDashboard({ t, lang, darkMode }) {
  const cardBg = darkMode ? "#0D1B2A" : "#fff";
  const textColor = darkMode ? "#E2E8F0" : DARK;
  const mutedColor = darkMode ? "#94A3B8" : "#64748B";
  const borderColor = darkMode ? "#1e2d3d" : "#E2E8F0";
  const bg = darkMode ? "#0a1628" : BG;

  const requests = [
    { student: lang === "ku" ? "سارا ج." : "Sara J.", time: "21 May · 09:00 AM", type: "Online" },
    { student: lang === "ku" ? "هانا ک." : "Hana K.", time: "22 May · 04:00 PM", type: "Online" },
    { student: lang === "ku" ? "عەلی ر." : "Ali R.", time: "23 May · 11:30 AM", type: "In-Person" },
  ];

  const earningsData = [12, 18, 22, 15, 28, 32, 24, 35, 28, 40, 38, 45];
  const maxEarning = Math.max(...earningsData);

  return (
    <div style={{ background: bg, minHeight: "100vh", direction: t.dir }}>
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "32px 24px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 28 }}>
          <div>
            <h1 style={{ fontSize: 24, fontWeight: 800, color: textColor, margin: "0 0 4px" }}>
              {lang === "ku" ? "خێر بێیت، زانا! 👋" : lang === "ar" ? "مرحباً، زانا! 👋" : "Welcome back, Zana! 👋"}
            </h1>
            <p style={{ color: mutedColor, margin: 0, fontSize: 14 }}>
              {lang === "ku" ? "پیشاندانی زانیاریەکانی تۆ" : lang === "ar" ? "هذا ملخص بياناتك" : "Here's your overview"}
            </p>
          </div>
          <Btn>{lang === "ku" ? "+ زیادکردنی کاتی بەردەست" : lang === "ar" ? "+ إضافة وقت متاح" : "+ Add Availability"}</Btn>
        </div>

        {/* Stats */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 24 }}>
          {[
            { label: lang === "ku" ? "کۆی پۆلەکان" : lang === "ar" ? "إجمالي الجلسات" : "Total Sessions", value: "32", icon: "📅" },
            { label: lang === "ku" ? "کۆی داهات" : lang === "ar" ? "إجمالي الأرباح" : "Total Earnings", value: "420,000 IQD", icon: "💰", orange: true },
            { label: lang === "ku" ? "داواکارییەکان" : lang === "ar" ? "الطلبات" : "Requests", value: "8", icon: "📨" },
            { label: lang === "ku" ? "هەڵسەنگاندن" : lang === "ar" ? "التقييم" : "Avg Rating", value: "4.8 ★", icon: "⭐" },
          ].map(stat => (
            <div key={stat.label} style={{ background: cardBg, borderRadius: 14, border: `1px solid ${borderColor}`, padding: 18 }}>
              <div style={{ fontSize: 26, marginBottom: 8 }}>{stat.icon}</div>
              <div style={{ fontSize: stat.value.length > 8 ? 17 : 22, fontWeight: 800, color: stat.orange ? ORANGE : textColor }}>{stat.value}</div>
              <div style={{ fontSize: 12, color: mutedColor, marginTop: 2 }}>{stat.label}</div>
            </div>
          ))}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 300px", gap: 20 }}>
          {/* Earnings Chart */}
          <div style={{ background: cardBg, borderRadius: 16, border: `1px solid ${borderColor}`, padding: 22 }}>
            <h3 style={{ fontWeight: 700, fontSize: 16, color: textColor, margin: "0 0 20px" }}>
              {lang === "ku" ? "داهاتی مانگانە" : lang === "ar" ? "الأرباح الشهرية" : "Monthly Earnings"} (IQD ×1000)
            </h3>
            <div style={{ display: "flex", alignItems: "flex-end", gap: 8, height: 140 }}>
              {earningsData.map((v, i) => (
                <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                  <div style={{
                    width: "100%", background: i === earningsData.length - 1 ? ORANGE : ORANGE + "40",
                    borderRadius: "4px 4px 0 0", height: `${(v / maxEarning) * 120}px`,
                    transition: "height 0.3s"
                  }} />
                  <span style={{ fontSize: 9, color: mutedColor }}>
                    {["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"][i]}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Pending Requests */}
          <div style={{ background: cardBg, borderRadius: 16, border: `1px solid ${borderColor}`, padding: 22 }}>
            <h3 style={{ fontWeight: 700, fontSize: 16, color: textColor, margin: "0 0 16px" }}>
              {lang === "ku" ? "داواکارییە نوێیەکان" : lang === "ar" ? "الطلبات الجديدة" : "New Requests"}
            </h3>
            {requests.map((req, i) => (
              <div key={i} style={{ marginBottom: 14, paddingBottom: 14, borderBottom: i < requests.length - 1 ? `1px solid ${borderColor}` : "none" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                  <Avatar initials={req.student.slice(0, 2)} size={36} color={avatarColors[i]} />
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 13, color: textColor }}>{req.student}</div>
                    <div style={{ fontSize: 11, color: mutedColor }}>{req.time} · {req.type}</div>
                  </div>
                </div>
                <div style={{ display: "flex", gap: 6 }}>
                  <button style={{ flex: 1, padding: "6px 0", borderRadius: 8, border: "none", background: "#22C55E", color: "#fff", cursor: "pointer", fontWeight: 600, fontSize: 12 }}>
                    {lang === "ku" ? "پەسەندکردن" : lang === "ar" ? "قبول" : "Accept"}
                  </button>
                  <button style={{ flex: 1, padding: "6px 0", borderRadius: 8, border: "none", background: "#EF4444", color: "#fff", cursor: "pointer", fontWeight: 600, fontSize: 12 }}>
                    {lang === "ku" ? "ڕەتکردنەوە" : lang === "ar" ? "رفض" : "Decline"}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Subscription */}
        <div style={{ background: cardBg, borderRadius: 16, border: `1px solid ${borderColor}`, padding: 22, marginTop: 20 }}>
          <h3 style={{ fontWeight: 700, fontSize: 16, color: textColor, margin: "0 0 16px" }}>
            {lang === "ku" ? "پلانی بەشداری" : lang === "ar" ? "خطة الاشتراك" : "Subscription Plans"}
          </h3>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14 }}>
            {[
              { name: "Free", price: "0", color: "#64748B", features: [lang === "ku" ? "پڕۆفایلی سادە" : "Basic Profile", lang === "ku" ? "دیمەنی کەم" : "Limited Visibility"] },
              { name: "Pro", price: "50,000", color: ORANGE, current: true, features: [lang === "ku" ? "لیستی تایبەت" : "Featured Listing", lang === "ku" ? "زیاتر دیارە" : "More Visibility", lang === "ku" ? "ئامارەکان" : "Analytics"] },
              { name: "Business", price: "150,000", color: DARK, features: [lang === "ku" ? "پێشینی بەرز" : "Priority Ranking", lang === "ku" ? "دروستکردنی لید" : "Lead Generation", lang === "ku" ? "نیشانی دروستکراو" : "Verified Badge"] },
            ].map(plan => (
              <div key={plan.name} style={{
                borderRadius: 12, padding: 18, border: `2px solid ${plan.current ? ORANGE : borderColor}`,
                background: plan.current ? ORANGE + "0a" : bg, position: "relative"
              }}>
                {plan.current && <div style={{ position: "absolute", top: -10, left: "50%", transform: "translateX(-50%)", background: ORANGE, color: "#fff", fontSize: 10, padding: "2px 10px", borderRadius: 10, fontWeight: 700, whiteSpace: "nowrap" }}>
                  {lang === "ku" ? "ئێستا" : lang === "ar" ? "الحالي" : "Current"}
                </div>}
                <div style={{ fontWeight: 800, fontSize: 16, color: plan.color, marginBottom: 4 }}>{plan.name}</div>
                <div style={{ fontSize: 18, fontWeight: 700, color: textColor, marginBottom: 12 }}>{plan.price} IQD<span style={{ fontSize: 11, color: mutedColor }}>/{lang === "ku" ? "مانگ" : lang === "ar" ? "شهر" : "mo"}</span></div>
                {plan.features.map(f => <div key={f} style={{ fontSize: 12, color: mutedColor, padding: "3px 0" }}>✓ {f}</div>)}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── ADMIN DASHBOARD ───────────────────────────────────────────────────────────
function AdminDashboard({ t, lang, darkMode }) {
  const cardBg = darkMode ? "#0D1B2A" : "#fff";
  const textColor = darkMode ? "#E2E8F0" : DARK;
  const mutedColor = darkMode ? "#94A3B8" : "#64748B";
  const borderColor = darkMode ? "#1e2d3d" : "#E2E8F0";
  const bg = darkMode ? "#0a1628" : BG;
  const [adminTab, setAdminTab] = useState("teachers");

  const pendingTeachers = [
    { name: lang === "ku" ? "زانا ئەحمەد" : "Zana Ahmed", subject: "English Teacher", rating: 4.8, initials: "ZA", color: ORANGE },
    { name: lang === "ku" ? "هانا کەریم" : "Hana Karim", subject: "IELTS Instructor", rating: 4.9, initials: "HK", color: DARK },
  ];

  const revenueData = [18, 22, 28, 32, 24, 38, 42, 35, 48, 52, 44, 58];
  const maxRev = Math.max(...revenueData);

  return (
    <div style={{ background: bg, minHeight: "100vh", direction: t.dir }}>
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "32px 24px" }}>
        <h1 style={{ fontSize: 26, fontWeight: 800, color: textColor, margin: "0 0 24px" }}>
          {lang === "ku" ? "پانێڵی بەڕێوەبران" : lang === "ar" ? "لوحة الإدارة" : "Admin Dashboard"}
        </h1>

        {/* Global Stats */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 12, marginBottom: 24 }}>
          {[
            { label: lang === "ku" ? "کۆی بەکارهێنەران" : "Total Users", value: "12,540", icon: "👥", color: "#2563EB" },
            { label: lang === "ku" ? "مامۆستاکان" : "Teachers", value: "1,250", icon: "👨‍🏫", color: ORANGE },
            { label: lang === "ku" ? "قوتابخانەکان" : "Schools", value: "45", icon: "🏫", color: "#16A34A" },
            { label: lang === "ku" ? "داهاتی کۆتا مانگ" : "Revenue", value: "25.6M IQD", icon: "💰", color: "#7C3AED" },
            { label: lang === "ku" ? "هەڵسەنگاندنەکان" : "Reviews", value: "3,450", icon: "⭐", color: "#F59E0B" },
          ].map(stat => (
            <div key={stat.label} style={{ background: cardBg, borderRadius: 14, border: `1px solid ${borderColor}`, padding: 16 }}>
              <div style={{ fontSize: 22, marginBottom: 6 }}>{stat.icon}</div>
              <div style={{ fontSize: 18, fontWeight: 800, color: stat.color }}>{stat.value}</div>
              <div style={{ fontSize: 11, color: mutedColor, marginTop: 2 }}>{stat.label}</div>
            </div>
          ))}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 20, marginBottom: 20 }}>
          {/* Revenue Chart */}
          <div style={{ background: cardBg, borderRadius: 16, border: `1px solid ${borderColor}`, padding: 22 }}>
            <h3 style={{ fontWeight: 700, fontSize: 16, color: textColor, margin: "0 0 6px" }}>
              {lang === "ku" ? "داهاتی ساڵانە" : lang === "ar" ? "الإيرادات السنوية" : "Annual Revenue"} (IQD ×M)
            </h3>
            <div style={{ fontSize: 28, fontWeight: 900, color: ORANGE, marginBottom: 16 }}>25,600,000 IQD</div>
            <div style={{ display: "flex", alignItems: "flex-end", gap: 6, height: 120 }}>
              {revenueData.map((v, i) => (
                <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                  <div style={{
                    width: "100%", background: i >= 8 ? ORANGE : ORANGE + "35",
                    borderRadius: "4px 4px 0 0", height: `${(v / maxRev) * 100}px`
                  }} />
                  <span style={{ fontSize: 9, color: mutedColor }}>
                    {["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"][i]}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Top Categories */}
          <div style={{ background: cardBg, borderRadius: 16, border: `1px solid ${borderColor}`, padding: 22 }}>
            <h3 style={{ fontWeight: 700, fontSize: 16, color: textColor, margin: "0 0 16px" }}>
              {lang === "ku" ? "باشترین پۆلەکان" : lang === "ar" ? "أفضل الفئات" : "Top Categories"}
            </h3>
            {[
              { name: "Languages", pct: 38 },
              { name: "Programming", pct: 25 },
              { name: "Math/Science", pct: 18 },
              { name: "Design", pct: 11 },
              { name: "Business", pct: 8 },
            ].map(cat => (
              <div key={cat.name} style={{ marginBottom: 14 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4, fontSize: 13 }}>
                  <span style={{ color: textColor, fontWeight: 500 }}>{cat.name}</span>
                  <span style={{ color: ORANGE, fontWeight: 700 }}>{cat.pct}%</span>
                </div>
                <div style={{ height: 6, background: borderColor, borderRadius: 4 }}>
                  <div style={{ height: "100%", width: `${cat.pct}%`, background: ORANGE, borderRadius: 4 }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Management Tabs */}
        <div style={{ background: cardBg, borderRadius: 16, border: `1px solid ${borderColor}`, padding: 22 }}>
          <div style={{ display: "flex", gap: 6, marginBottom: 20, borderBottom: `1px solid ${borderColor}`, paddingBottom: 16 }}>
            {[
              { key: "teachers", label: lang === "ku" ? "مامۆستاکان" : lang === "ar" ? "المعلمون" : "Teachers" },
              { key: "schools", label: lang === "ku" ? "قوتابخانەکان" : lang === "ar" ? "المدارس" : "Schools" },
              { key: "categories", label: lang === "ku" ? "پۆلەکان" : lang === "ar" ? "الفئات" : "Categories" },
            ].map(tab => (
              <button key={tab.key} onClick={() => setAdminTab(tab.key)} style={{
                padding: "8px 18px", borderRadius: 8, border: "none", cursor: "pointer",
                fontSize: 13, fontWeight: 600,
                background: adminTab === tab.key ? ORANGE : "transparent",
                color: adminTab === tab.key ? "#fff" : mutedColor,
                transition: "all 0.15s"
              }}>{tab.label}</button>
            ))}
          </div>

          {adminTab === "teachers" && (
            <div>
              <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
                {["Pending", "Approved", "Rejected"].map(s => (
                  <span key={s} style={{
                    padding: "4px 12px", borderRadius: 8, fontSize: 12, fontWeight: 600,
                    background: s === "Pending" ? "#FEF3C7" : s === "Approved" ? "#DCFCE7" : "#FEE2E2",
                    color: s === "Pending" ? "#92400E" : s === "Approved" ? "#166534" : "#991B1B"
                  }}>{s}: {s === "Pending" ? "12" : s === "Approved" ? "1,230" : "8"}</span>
                ))}
              </div>
              {pendingTeachers.map((teacher, i) => (
                <div key={i} style={{
                  display: "flex", alignItems: "center", gap: 12,
                  padding: "14px 0", borderBottom: `1px solid ${borderColor}`
                }}>
                  <Avatar initials={teacher.initials} size={44} color={teacher.color} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, fontSize: 14, color: textColor }}>{teacher.name}</div>
                    <div style={{ fontSize: 12, color: mutedColor }}>{teacher.subject}</div>
                    <Stars rating={teacher.rating} size={11} />
                  </div>
                  <div style={{ display: "flex", gap: 8 }}>
                    <button style={{ padding: "7px 16px", borderRadius: 8, border: "none", background: "#22C55E", color: "#fff", cursor: "pointer", fontWeight: 600, fontSize: 13 }}>
                      {lang === "ku" ? "پەسەندکردن" : "Approve"}
                    </button>
                    <button style={{ padding: "7px 16px", borderRadius: 8, border: "none", background: "#EF4444", color: "#fff", cursor: "pointer", fontWeight: 600, fontSize: 13 }}>
                      {lang === "ku" ? "ڕەتکردنەوە" : "Reject"}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {adminTab === "schools" && (
            <div>
              {schools.map((school, i) => {
                const name = lang === "ar" ? school.nameAr : lang === "ku" ? school.nameKu : school.name;
                return (
                  <div key={i} style={{
                    display: "flex", alignItems: "center", gap: 12,
                    padding: "14px 0", borderBottom: `1px solid ${borderColor}`
                  }}>
                    <div style={{ width: 44, height: 44, borderRadius: 10, background: ORANGE + "18", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>🏫</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 700, fontSize: 14, color: textColor }}>{name}</div>
                      <div style={{ fontSize: 12, color: mutedColor }}>📍 {school.location}</div>
                    </div>
                    <Badge color="#22C55E">{lang === "ku" ? "پەسەندکراو" : "Approved"}</Badge>
                  </div>
                );
              })}
            </div>
          )}

          {adminTab === "categories" && (
            <div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
                {categories.map((cat, i) => (
                  <div key={i} style={{
                    padding: "10px 16px", borderRadius: 10, border: `1px solid ${borderColor}`,
                    display: "flex", alignItems: "center", gap: 8, fontSize: 14, color: textColor, fontWeight: 500
                  }}>
                    <span>{cat.icon}</span>
                    <span>{lang === "ar" ? cat.labelAr : lang === "ku" ? cat.labelKu : cat.label}</span>
                    <button style={{ background: "none", border: "none", color: "#EF4444", cursor: "pointer", fontSize: 16, padding: 0 }}>×</button>
                  </div>
                ))}
                <button style={{ padding: "10px 16px", borderRadius: 10, border: `1.5px dashed ${ORANGE}`, background: ORANGE + "0a", color: ORANGE, cursor: "pointer", fontWeight: 600, fontSize: 14 }}>
                  + {lang === "ku" ? "پۆلی نوێ" : lang === "ar" ? "فئة جديدة" : "Add Category"}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── CHAT PAGE ─────────────────────────────────────────────────────────────────
function ChatPage({ t, lang, darkMode }) {
  const cardBg = darkMode ? "#0D1B2A" : "#fff";
  const textColor = darkMode ? "#E2E8F0" : DARK;
  const mutedColor = darkMode ? "#94A3B8" : "#64748B";
  const borderColor = darkMode ? "#1e2d3d" : "#E2E8F0";
  const bg = darkMode ? "#0a1628" : BG;
  const [msg, setMsg] = useState("");
  const [messages, setMessages] = useState([
    { from: "other", text: lang === "ku" ? "سڵاو! چۆنی یارمەتیت بکەم؟" : lang === "ar" ? "مرحباً! كيف يمكنني مساعدتك؟" : "Hi! How can I help you?", time: "10:00 AM" },
    { from: "me", text: lang === "ku" ? "دەمەوێت ئامادەبم بۆ IELTS" : lang === "ar" ? "أريد التحضير لـ IELTS" : "I want to prepare for IELTS", time: "10:01 AM" },
    { from: "other", text: lang === "ku" ? "زۆر باشە! دەتوانم یارمەتیت بدەم" : lang === "ar" ? "رائع! يمكنني مساعدتك في ذلك" : "Great! I can definitely help you with that", time: "10:02 AM" },
    { from: "me", text: lang === "ku" ? "کەی دەتوانین دەست پێ بکەین؟" : lang === "ar" ? "متى يمكننا البدء؟" : "When can we start?", time: "10:03 AM" },
    { from: "other", text: lang === "ku" ? "دووشەممە و چوارشەممە بەردەستم" : lang === "ar" ? "أنا متاحة الإثنين والأربعاء" : "I'm available Monday and Wednesday", time: "10:04 AM" },
  ]);

  const contacts = [
    { name: lang === "ku" ? "زانا ئەحمەد" : "Zana Ahmed", last: lang === "ku" ? "بەردەستم دووشەممە..." : "I'm available Mon...", initials: "ZA", color: ORANGE, online: true, unread: 2 },
    { name: lang === "ku" ? "هانا کەریم" : "Hana Karim", last: lang === "ku" ? "سوپاست دەکەم!" : "Thank you! See you tomorrow", initials: "HK", color: DARK, online: false, unread: 0 },
    { name: lang === "ku" ? "قوتابخانەی نێودەوڵەتی" : "Future School", last: lang === "ku" ? "سوپاس بۆ پرسیارەکەت" : "Thanks for your inquiry", initials: "FS", color: "#16A34A", online: true, unread: 1 },
  ];

  const sendMessage = () => {
    if (!msg.trim()) return;
    setMessages(prev => [...prev, { from: "me", text: msg, time: "Now" }]);
    setMsg("");
  };

  return (
    <div style={{ background: bg, height: "calc(100vh - 60px)", direction: t.dir, display: "flex" }}>
      {/* Contacts */}
      <div style={{ width: 280, background: cardBg, borderRight: `1px solid ${borderColor}`, display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "16px 16px 8px" }}>
          <h3 style={{ fontWeight: 700, fontSize: 16, color: textColor, margin: "0 0 12px" }}>
            {lang === "ku" ? "نامەکان" : lang === "ar" ? "الرسائل" : "Messages"}
          </h3>
          <input placeholder={lang === "ku" ? "گەڕان..." : lang === "ar" ? "بحث..." : "Search..."} style={{
            width: "100%", border: `1px solid ${borderColor}`, borderRadius: 8, padding: "8px 12px",
            fontSize: 13, background: bg, color: textColor, outline: "none", boxSizing: "border-box"
          }} />
        </div>
        <div style={{ flex: 1, overflowY: "auto" }}>
          {contacts.map((contact, i) => (
            <div key={i} style={{
              padding: "12px 16px", cursor: "pointer", borderBottom: `1px solid ${borderColor}`,
              background: i === 0 ? ORANGE + "0d" : "transparent",
              display: "flex", gap: 10, alignItems: "center"
            }}>
              <div style={{ position: "relative" }}>
                <Avatar initials={contact.initials} size={40} color={contact.color} />
                {contact.online && <div style={{ position: "absolute", bottom: 1, right: 1, width: 10, height: 10, borderRadius: "50%", background: "#22C55E", border: "2px solid #fff" }} />}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontWeight: 600, fontSize: 13, color: textColor }}>{contact.name}</span>
                  {contact.unread > 0 && <span style={{ background: ORANGE, color: "#fff", borderRadius: "50%", width: 18, height: 18, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700 }}>{contact.unread}</span>}
                </div>
                <div style={{ fontSize: 11, color: mutedColor, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{contact.last}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Chat */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "14px 20px", background: cardBg, borderBottom: `1px solid ${borderColor}`, display: "flex", alignItems: "center", gap: 12 }}>
          <Avatar initials="ZA" size={38} color={ORANGE} />
          <div>
            <div style={{ fontWeight: 700, fontSize: 15, color: textColor }}>{lang === "ku" ? "زانا ئەحمەد" : "Zana Ahmed"}</div>
            <div style={{ fontSize: 11, color: "#22C55E" }}>● {lang === "ku" ? "ئۆنلاینە" : lang === "ar" ? "متاح" : "Online"}</div>
          </div>
        </div>
        <div style={{ flex: 1, overflowY: "auto", padding: 20, display: "flex", flexDirection: "column", gap: 10 }}>
          {messages.map((m, i) => (
            <div key={i} style={{
              display: "flex", justifyContent: m.from === "me" ? "flex-end" : "flex-start"
            }}>
              <div style={{
                maxWidth: "65%", padding: "10px 14px", borderRadius: m.from === "me" ? "16px 16px 4px 16px" : "16px 16px 16px 4px",
                background: m.from === "me" ? ORANGE : cardBg,
                border: m.from === "me" ? "none" : `1px solid ${borderColor}`,
                color: m.from === "me" ? "#fff" : textColor,
                fontSize: 14
              }}>
                {m.text}
                <div style={{ fontSize: 10, opacity: 0.7, marginTop: 4, textAlign: m.from === "me" ? "right" : "left" }}>{m.time}</div>
              </div>
            </div>
          ))}
        </div>
        <div style={{ padding: 16, background: cardBg, borderTop: `1px solid ${borderColor}`, display: "flex", gap: 10 }}>
          <input
            value={msg} onChange={e => setMsg(e.target.value)}
            onKeyDown={e => e.key === "Enter" && sendMessage()}
            placeholder={lang === "ku" ? "نامەیەک بنووسە..." : lang === "ar" ? "اكتب رسالة..." : "Type a message..."}
            style={{
              flex: 1, border: `1px solid ${borderColor}`, borderRadius: 10, padding: "10px 14px",
              fontSize: 14, background: bg, color: textColor, outline: "none"
            }}
          />
          <button onClick={sendMessage} style={{
            background: ORANGE, color: "#fff", border: "none", borderRadius: 10,
            padding: "0 18px", cursor: "pointer", fontSize: 20
          }}>➤</button>
        </div>
      </div>
    </div>
  );
}

// ─── LOGIN / REGISTER PAGE ─────────────────────────────────────────────────────
function AuthPage({ t, lang, darkMode, setView, mode }) {
  const cardBg = darkMode ? "#0D1B2A" : "#fff";
  const textColor = darkMode ? "#E2E8F0" : DARK;
  const mutedColor = darkMode ? "#94A3B8" : "#64748B";
  const borderColor = darkMode ? "#1e2d3d" : "#E2E8F0";
  const bg = darkMode ? "#0a1628" : BG;
  const [role, setRole] = useState("student");

  return (
    <div style={{
      background: bg, minHeight: "100vh", display: "flex",
      alignItems: "center", justifyContent: "center", direction: t.dir, padding: 24
    }}>
      <div style={{ background: cardBg, borderRadius: 20, border: `1px solid ${borderColor}`, padding: 40, width: "100%", maxWidth: 420 }}>
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <div style={{
            width: 52, height: 52, borderRadius: 14, background: ORANGE,
            display: "flex", alignItems: "center", justifyContent: "center",
            color: "#fff", fontWeight: 900, fontSize: 26, margin: "0 auto 12px"
          }}>F</div>
          <h2 style={{ fontWeight: 800, fontSize: 22, color: textColor, margin: "0 0 4px" }}>
            {mode === "login"
              ? (lang === "ku" ? "خێر بێیتەوە!" : lang === "ar" ? "مرحباً بعودتك!" : "Welcome Back!")
              : (lang === "ku" ? "بەشداری فێرگا بکە" : lang === "ar" ? "انضم إلى فيرغا" : "Join FERGA")}
          </h2>
          <p style={{ color: mutedColor, fontSize: 14, margin: 0 }}>
            {mode === "login"
              ? (lang === "ku" ? "چوونەژوورەوە بۆ ئەکاونتەکەت" : lang === "ar" ? "سجل دخولك إلى حسابك" : "Login to your account")
              : (lang === "ku" ? "ئەکاونتی فێرگا دروست بکە" : lang === "ar" ? "أنشئ حساب فيرغا" : "Create your FERGA account")}
          </p>
        </div>

        {mode === "register" && (
          <div style={{ marginBottom: 18 }}>
            <label style={{ fontSize: 13, fontWeight: 600, color: mutedColor, display: "block", marginBottom: 8 }}>
              {lang === "ku" ? "جۆری ئەکاونت" : lang === "ar" ? "نوع الحساب" : "Account Type"}
            </label>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              {[
                { key: "student", icon: "🎓", label: lang === "ku" ? "خوێندکار" : lang === "ar" ? "طالب" : "Student" },
                { key: "teacher", icon: "👨‍🏫", label: lang === "ku" ? "مامۆستا" : lang === "ar" ? "معلم" : "Teacher" },
                { key: "school", icon: "🏫", label: lang === "ku" ? "قوتابخانە" : lang === "ar" ? "مدرسة" : "School" },
                { key: "institute", icon: "🏛️", label: lang === "ku" ? "ئینستیتوت" : lang === "ar" ? "معهد" : "Institute" },
              ].map(r => (
                <button key={r.key} onClick={() => setRole(r.key)} style={{
                  padding: "10px 0", borderRadius: 10, border: `1.5px solid ${role === r.key ? ORANGE : borderColor}`,
                  background: role === r.key ? ORANGE + "12" : "transparent",
                  color: role === r.key ? ORANGE : mutedColor,
                  cursor: "pointer", fontWeight: 600, fontSize: 13, display: "flex",
                  alignItems: "center", justifyContent: "center", gap: 6, transition: "all 0.15s"
                }}>{r.icon} {r.label}</button>
              ))}
            </div>
          </div>
        )}

        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {mode === "register" && (
            <input placeholder={lang === "ku" ? "ناوی تەواو" : lang === "ar" ? "الاسم الكامل" : "Full Name"} style={{
              border: `1px solid ${borderColor}`, borderRadius: 10, padding: "12px 14px",
              fontSize: 14, background: bg, color: textColor, outline: "none"
            }} />
          )}
          <input placeholder={lang === "ku" ? "ئیمەیڵ یان ژمارەی مۆبایل" : lang === "ar" ? "البريد الإلكتروني أو رقم الهاتف" : "Email or Phone"} style={{
            border: `1px solid ${borderColor}`, borderRadius: 10, padding: "12px 14px",
            fontSize: 14, background: bg, color: textColor, outline: "none"
          }} />
          <input type="password" placeholder={lang === "ku" ? "وشەی نهێنی" : lang === "ar" ? "كلمة المرور" : "Password"} style={{
            border: `1px solid ${borderColor}`, borderRadius: 10, padding: "12px 14px",
            fontSize: 14, background: bg, color: textColor, outline: "none"
          }} />
          {mode === "register" && (
            <input type="password" placeholder={lang === "ku" ? "دووبارەکردنەوەی وشەی نهێنی" : lang === "ar" ? "تأكيد كلمة المرور" : "Confirm Password"} style={{
              border: `1px solid ${borderColor}`, borderRadius: 10, padding: "12px 14px",
              fontSize: 14, background: bg, color: textColor, outline: "none"
            }} />
          )}

          <button onClick={() => mode === "login" ? setView("studentDashboard") : setView("home")} style={{
            background: ORANGE, color: "#fff", border: "none", borderRadius: 10,
            padding: "14px 0", fontWeight: 700, fontSize: 15, cursor: "pointer", width: "100%"
          }}>
            {mode === "login" ? t.login : t.register}
          </button>
        </div>

        <div style={{ textAlign: "center", margin: "18px 0", color: mutedColor, fontSize: 13 }}>
          {lang === "ku" ? "یان" : lang === "ar" ? "أو" : "or"}
        </div>

        <div style={{ display: "flex", gap: 10 }}>
          <button style={{
            flex: 1, padding: "11px 0", borderRadius: 10, border: `1px solid ${borderColor}`,
            background: "transparent", cursor: "pointer", fontSize: 13, fontWeight: 600,
            color: textColor, display: "flex", alignItems: "center", justifyContent: "center", gap: 6
          }}>🔵 Google</button>
          <button style={{
            flex: 1, padding: "11px 0", borderRadius: 10, border: `1px solid ${borderColor}`,
            background: "transparent", cursor: "pointer", fontSize: 13, fontWeight: 600,
            color: textColor, display: "flex", alignItems: "center", justifyContent: "center", gap: 6
          }}>🍎 Apple</button>
        </div>

        <p style={{ textAlign: "center", marginTop: 20, fontSize: 13, color: mutedColor }}>
          {mode === "login"
            ? (lang === "ku" ? "ئەکاونتت نییە؟" : lang === "ar" ? "ليس لديك حساب؟" : "Don't have an account?")
            : (lang === "ku" ? "ئەکاونتت هەیە؟" : lang === "ar" ? "لديك حساب بالفعل؟" : "Already have an account?")}
          {" "}
          <button onClick={() => setView(mode === "login" ? "register" : "login")} style={{
            background: "none", border: "none", color: ORANGE, fontWeight: 700, cursor: "pointer", fontSize: 13
          }}>
            {mode === "login" ? t.register : t.login}
          </button>
        </p>
      </div>
    </div>
  );
}

// ─── SIDE NAV for Dashboards ───────────────────────────────────────────────────
function DashboardLayout({ children, t, lang, darkMode, view, setView }) {
  const cardBg = darkMode ? "#0D1B2A" : "#fff";
  const textColor = darkMode ? "#E2E8F0" : DARK;
  const mutedColor = darkMode ? "#94A3B8" : "#64748B";
  const borderColor = darkMode ? "#1e2d3d" : "#E2E8F0";

  const dashMenus = {
    studentDashboard: [
      { icon: "🏠", label: t.home, key: "home" },
      { icon: "📅", label: t.bookings, key: "studentDashboard" },
      { icon: "📚", label: t.courses, key: "courses" },
      { icon: "❤️", label: t.saved, key: "studentDashboard" },
      { icon: "💬", label: "Chat", key: "chat" },
      { icon: "🔔", label: t.notifications, key: "studentDashboard" },
      { icon: "⚙️", label: t.settings, key: "studentDashboard" },
    ],
    teacherDashboard: [
      { icon: "🏠", label: t.home, key: "home" },
      { icon: "📅", label: t.bookings, key: "teacherDashboard" },
      { icon: "👥", label: t.students, key: "teacherDashboard" },
      { icon: "💰", label: t.earnings, key: "teacherDashboard" },
      { icon: "💬", label: "Chat", key: "chat" },
      { icon: "⭐", label: t.reviews, key: "teacherDashboard" },
      { icon: "⚙️", label: t.settings, key: "teacherDashboard" },
    ],
    adminDashboard: [
      { icon: "📊", label: t.dashboard, key: "adminDashboard" },
      { icon: "👥", label: lang === "ku" ? "بەکارهێنەران" : "Users", key: "adminDashboard" },
      { icon: "👨‍🏫", label: t.teachers, key: "adminDashboard" },
      { icon: "🏫", label: t.schools, key: "adminDashboard" },
      { icon: "📚", label: t.courses, key: "adminDashboard" },
      { icon: "💰", label: t.earnings, key: "adminDashboard" },
      { icon: "⚙️", label: t.settings, key: "adminDashboard" },
    ],
  };

  const menu = dashMenus[view] || dashMenus.studentDashboard;

  return (
    <div style={{ display: "flex", direction: t.dir }}>
      <div style={{
        width: 220, background: cardBg, borderRight: `1px solid ${borderColor}`,
        minHeight: "calc(100vh - 60px)", padding: "20px 0", flexShrink: 0
      }}>
        {menu.map(item => (
          <button key={item.label} onClick={() => setView(item.key)} style={{
            width: "100%", padding: "11px 20px", border: "none",
            background: view === item.key ? ORANGE + "15" : "transparent",
            color: view === item.key ? ORANGE : mutedColor,
            fontWeight: view === item.key ? 700 : 500, cursor: "pointer",
            fontSize: 14, display: "flex", alignItems: "center", gap: 10,
            borderLeft: view === item.key ? `3px solid ${ORANGE}` : "3px solid transparent",
            transition: "all 0.15s", fontFamily: "inherit", textAlign: "left"
          }}>
            <span>{item.icon}</span> {item.label}
          </button>
        ))}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>{children}</div>
    </div>
  );
}

// ─── MAIN APP ──────────────────────────────────────────────────────────────────
export default function FergaApp() {
  const [lang, setLang] = useState("ku");
  const [view, setView] = useState("home");
  const [darkMode, setDarkMode] = useState(false);
  const t = translations[lang];

  const dashboardViews = ["studentDashboard", "teacherDashboard", "adminDashboard"];

  const renderView = () => {
    switch (view) {
      case "home": return <HomePage t={t} lang={lang} setView={setView} darkMode={darkMode} />;
      case "teachers": return <TeachersPage t={t} lang={lang} darkMode={darkMode} setView={setView} />;
      case "courses": return <HomePage t={t} lang={lang} setView={setView} darkMode={darkMode} />;
      case "schools": return <HomePage t={t} lang={lang} setView={setView} darkMode={darkMode} />;
      case "teacherProfile": return <TeacherProfilePage t={t} lang={lang} darkMode={darkMode} setView={setView} />;
      case "booking": return <BookingPage t={t} lang={lang} darkMode={darkMode} setView={setView} />;
      case "login": return <AuthPage t={t} lang={lang} darkMode={darkMode} setView={setView} mode="login" />;
      case "register": return <AuthPage t={t} lang={lang} darkMode={darkMode} setView={setView} mode="register" />;
      case "chat": return (
        <DashboardLayout t={t} lang={lang} darkMode={darkMode} view="studentDashboard" setView={setView}>
          <ChatPage t={t} lang={lang} darkMode={darkMode} />
        </DashboardLayout>
      );
      case "studentDashboard": return (
        <DashboardLayout t={t} lang={lang} darkMode={darkMode} view="studentDashboard" setView={setView}>
          <StudentDashboard t={t} lang={lang} darkMode={darkMode} />
        </DashboardLayout>
      );
      case "teacherDashboard": return (
        <DashboardLayout t={t} lang={lang} darkMode={darkMode} view="teacherDashboard" setView={setView}>
          <TeacherDashboard t={t} lang={lang} darkMode={darkMode} />
        </DashboardLayout>
      );
      case "adminDashboard": return (
        <DashboardLayout t={t} lang={lang} darkMode={darkMode} view="adminDashboard" setView={setView}>
          <AdminDashboard t={t} lang={lang} darkMode={darkMode} />
        </DashboardLayout>
      );
      case "courseDetail": return <HomePage t={t} lang={lang} setView={setView} darkMode={darkMode} />;
      default: return <HomePage t={t} lang={lang} setView={setView} darkMode={darkMode} />;
    }
  };

  return (
    <div style={{ fontFamily: "system-ui, -apple-system, sans-serif", minHeight: "100vh" }}>
      <Navbar lang={lang} setLang={setLang} setView={setView} t={t} darkMode={darkMode} setDarkMode={setDarkMode} />

      {/* Dashboard Quick Nav */}
      <div style={{
        background: darkMode ? "#0D1B2A" : "#fff",
        borderBottom: `1px solid ${darkMode ? "#1e2d3d" : "#E2E8F0"}`,
        padding: "6px 24px", display: "flex", gap: 6, overflowX: "auto",
        direction: t.dir
      }}>
        {[
          { key: "home", label: t.home, icon: "🏠" },
          { key: "teacherProfile", label: lang === "ku" ? "پڕۆفایلی مامۆستا" : lang === "ar" ? "ملف المعلم" : "Teacher Profile", icon: "👤" },
          { key: "booking", label: lang === "ku" ? "پشکنین" : lang === "ar" ? "حجز" : "Booking", icon: "📅" },
          { key: "studentDashboard", label: lang === "ku" ? "داشبۆردی خوێندکار" : lang === "ar" ? "لوحة الطالب" : "Student Dashboard", icon: "🎓" },
          { key: "teacherDashboard", label: lang === "ku" ? "داشبۆردی مامۆستا" : lang === "ar" ? "لوحة المعلم" : "Teacher Dashboard", icon: "👨‍🏫" },
          { key: "adminDashboard", label: lang === "ku" ? "داشبۆردی ئەدمین" : lang === "ar" ? "لوحة الإدارة" : "Admin Dashboard", icon: "⚙️" },
          { key: "chat", label: lang === "ku" ? "چات" : lang === "ar" ? "الدردشة" : "Chat", icon: "💬" },
        ].map(item => (
          <button key={item.key} onClick={() => setView(item.key)} style={{
            padding: "5px 12px", borderRadius: 8, border: "none", cursor: "pointer",
            fontSize: 12, fontWeight: view === item.key ? 700 : 500, whiteSpace: "nowrap",
            background: view === item.key ? ORANGE + "18" : "transparent",
            color: view === item.key ? ORANGE : darkMode ? "#94A3B8" : "#64748B",
            fontFamily: "inherit", display: "flex", alignItems: "center", gap: 4
          }}>{item.icon} {item.label}</button>
        ))}
      </div>

      {renderView()}
    </div>
  );
}
